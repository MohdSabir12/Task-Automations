import requests
#from decimal import Decimal
from datetime import datetime
import xml.etree.ElementTree as ET
import os

DATE_FORMAT = "%Y-%m-%d"
FLOAT_EQUAL_THRESHOLD = 0.001

# INPUT
EXCHANGEID = 28
SECTYPE = 10
INPUT_FILENAME = "C:\\Jacky\\SymbolsA.txt"
SDATE = datetime(1990, 9, 1)
EDATE = datetime(2020, 7, 7)

# MS API
MSAPI_URL            = "https://api.morningstar.com/service/mf/MarketPrice/mstarid/{}?accesscode={}&startdate={}&enddate={}"
MSAPI_ACCESSCODE     = "m8adldc9239b9vmc5zy74n1lu9qkm6e7"

# DAILY BAR
DAILYBAR_URL         = "http://mstxml.tenfore.com/IndexTS/?Username=MoHe14430&password=B8VLx2&instrument={}&sdate={}&edate={}&type=dailybar"
DAILYBAR_DATE_FORMAT = "%d-%m-%Y"
XML_NAMESPACE        = { 'ms': 'http://morningstar.com'}

# OUTPUT
OUTPUT_LOG_FILE      = "priceChecker.log"

OUTPUT_HEADER        = "Date of last trade,Exchange,Security Type,Symbol,Open price,High price,Low price,Last price,Cumulative volume,Open interest,Settlement price\n"

OUTPUT_DEL_FILE      = "90dayPatchFile_Del.txt"
OUTPUT_DEL_ROW       = "{date},28,10,{symbol},0,0,0,0,0,,\n"

OUTPUT_ADD_FILE      = "90dayPatchFile_Add-Correction.txt"
OUTPUT_ADD_ROW       = "{date},28,10,{symbol},{price},{price},{price},{price},,,\n"

# def WriteResultToFile(result):
#
#     with open(OUT_FILENAME, 'w') as f:
#         for instrumentDateGaps in result:
#             instrument, dateGapList = instrumentDateGaps
#
#             strBuilder = instrument
#
#             for dateGap in dateGapList:
#                 sdate, edate, days = dateGap
#                 strBuilder = "{},{},{},{}".format(strBuilder, sdate, edate, days)
#
#             f.write(strBuilder + '\n')
#
#     return

class DailyBarHelper:

    def __init__(self, url = DAILYBAR_URL, ns = XML_NAMESPACE):
        self.ns = ns
        self.url = url
        self.datesAndPrices = []

    def reset(self):
        self.datesAndPrices.clear()

    def getDatesAndPrices(self, instrument, sdate, edate):
        self.reset()
        trades = self._getDailyBar(instrument, sdate, edate)
        trades = trades[::-1] # reverse the list as day bar is in newest to oldest order

        if trades:
            for trade in trades:
                tradeDate = datetime.strptime(GetXmlNodeText(trade, "ms:fld[@id='D953']", self.ns), DAILYBAR_DATE_FORMAT)
                closePrice = float(GetXmlNodeText(trade, "ms:fld[@id='D2']", self.ns));
                self.datesAndPrices.append((tradeDate, closePrice))

        return self.datesAndPrices

    def _getDailyBar(self, instrument, sdate, edate):
        url = self.url.format(instrument, sdate.strftime(DAILYBAR_DATE_FORMAT), edate.strftime(DAILYBAR_DATE_FORMAT))

        response = requests.get(url)

        if response.status_code == 200:
            doc = ET.fromstring(response.text)

            if GetXmlNodeText(doc, "ms:report/ms:error", self.ns) == "OK":
                trades = doc.findall("ms:message/ms:trade", self.ns)
                if len(trades) > 0:
                    return trades

        return None

class MsApiHelper:
    def __init__(self, url, accessCode, ns):
        self.url = url
        self.accessCode = accessCode
        self.ns = ns
        self.datesAndPrices = []

    def reset(self):
        self.datesAndPrices.clear()

    def getDatesAndPrices(self, instrument, sdate, edate):
        self.reset()
        trades = self._getMarketPrice(instrument, sdate, edate)

        if trades:
            for trade in trades:
                tradeDate = datetime.strptime(trade.attrib["Date"], DATE_FORMAT);
                closePrice = float(trade.attrib["ClosePrice"]);
                self.datesAndPrices.append((tradeDate, closePrice))

        return self.datesAndPrices

    def _getMarketPrice(self, instrument, sdate, edate):
        url = self.url.format(instrument, self.accessCode, sdate.strftime(DATE_FORMAT), edate.strftime(DATE_FORMAT))

        response = requests.get(url)

        if response.status_code == 200:
            doc = ET.fromstring(response.text)

            trades = doc.findall("data/MarketPrice/r", self.ns)
            if len(trades) > 0:
                return trades

            # if self._getXmlNodeText(doc, "ms:report/ms:error", self.ns) == "OK":
            #     trades = doc.findall("ms:message/ms:trade", self.ns)
            #     if len(trades) > 0:
            #         return trades

        return None

def FloatEquals(lv, rv):
    return abs(lv - rv) < FLOAT_EQUAL_THRESHOLD

def GetXmlNodeText(doc, path, namespace):
    node = doc.find(path, namespace)
    if node is not None:
        return node.text

    return ""

def GetInstrumentsFromFile(fileName):

    instruList = []

    with open(fileName, 'r') as f:
        for line in f.readlines():
            if len(line) > 0 and line[0] != ';':
                line = line.replace('\n', '')
                instruList.append(line)

    return instruList

def Log(f, message):
    f.write(message)
    print(message)

def ProcessOneInstrument(symbol, f_add, f_del, f_log):
    try:
        Log(f_log, "Processing {}:".format(symbol))

        msApi = MsApiHelper(MSAPI_URL, MSAPI_ACCESSCODE, None)
        msData = msApi.getDatesAndPrices(symbol, SDATE, EDATE)
        msdataLen = len(msData)

        dailyBar = DailyBarHelper()
        daybarData = dailyBar.getDatesAndPrices("{}.{}.{}".format(EXCHANGEID, SECTYPE, symbol), SDATE, EDATE)
        daybarLen = len(daybarData)

        mi = di = 0
        addCount = adjCount = delCount = matchCount = 0

        if msdataLen == 0:
            Log(f_log, " no MS data")
        else:
            Log(f_log, " MS data start:{} end:{}".format(msData[0][0].strftime(DATE_FORMAT),
                                                         msData[-1][0].strftime(DATE_FORMAT)))

        if daybarLen == 0:
            Log(f_log, " no Daybar data")
        else:
            Log(f_log, " Daybar data start:{} end:{}".format(daybarData[0][0].strftime(DATE_FORMAT),
                                                             daybarData[-1][0].strftime(DATE_FORMAT)))

        Log(f_log, "\n")

        while mi < msdataLen or di < daybarLen:
            if mi < msdataLen:
                mdate, mprice = msData[mi]
            else:
                mdate, mprice = None, None

            if di < daybarLen:
                ddate, dprice = daybarData[di]
            else:
                ddate, dprice = None, None

            if mdate is not None and ddate is not None and mdate == ddate:
                if not FloatEquals(mprice, dprice):
                    # send correction
                    f_add.write(OUTPUT_ADD_ROW.format(**{"date": mdate, "symbol": symbol, "price": mprice}))
                    adjCount += 1
                else:
                    matchCount += 1
                mi += 1
                di += 1
            elif mdate is None or (ddate is not None and mdate > ddate):
                # send delete
                f_del.write(OUTPUT_DEL_ROW.format(**{"date": ddate, "symbol": symbol}))
                delCount += 1
                di += 1
            elif ddate is None or (mdate is not None and mdate < ddate):
                # send add
                f_add.write(OUTPUT_ADD_ROW.format(**{"date": mdate, "symbol": symbol, "price": mprice}))
                addCount += 1
                mi += 1
            else:
                # should not go into this
                break

        Log(f_log,
            "Processed {}, match={}, add={}, update={}, delete={}\n".format(symbol, matchCount, addCount, adjCount,
                                                                            delCount))
    except Exception as e:
        Log(f_log, e)
    finally:
        f_del.flush()
        f_add.flush()
        f_log.flush()

if __name__ == '__main__':
    symbolList = GetInstrumentsFromFile(INPUT_FILENAME)

    with open(OUTPUT_LOG_FILE, 'w') as f_log:

        if len(symbolList) == 0:
            Log(f_log, "No symbols to process")
            exit(-1)

        with open(OUTPUT_DEL_FILE, 'w') as f_del, open(OUTPUT_ADD_FILE, 'w') as f_add:
            for symbol in symbolList:
                ProcessOneInstrument(symbol, f_add, f_del, f_log)

        Log(f_log, "Done!")


